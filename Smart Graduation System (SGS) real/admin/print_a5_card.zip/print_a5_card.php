<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Student ID is missing!");
}

$student_id = $_GET['id'];

// Fetch student data
$stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    die("Student not found!");
}

// Fetch settings for branding
$raw_settings = $pdo->query("SELECT * FROM settings")->fetchAll();
$settings = [];
foreach ($raw_settings as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}

// Fix Class of duplication
$class_year = $settings['class_year'] ?? '2026';
if (stripos($class_year, 'Class of') !== false) {
    $footer_text = $class_year;
} else {
    $footer_text = "Class of " . $class_year;
}
?>
<!DOCTYPE html>
<html lang="so">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print - <?= htmlspecialchars($student_id) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;700;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f1f5f9;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .page-container {
            width: 210mm;
            height: 148mm;
            background: #fff;
            display: flex;
            align-items: center;
            position: relative;
        }

        /* Content Area - Stacked Vertically in the Left Half */
        .content-box {
            width: 50%; /* Left half of the card */
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px 20px 20px 60px; /* Increased left padding as requested */
            text-align: center;
            border-right: 1px dashed #e2e8f0; /* Center indicator line */
        }

        /* Top Accent for the left half */
        .content-box::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 50%;
            height: 6px;
            background: linear-gradient(90deg, #6366f1, #a855f7);
        }

        .photo-frame {
            width: 130px;
            height: 130px;
            margin-bottom: 20px;
        }

        .photo-frame img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 5px 20px rgba(99, 102, 241, 0.2);
        }

        .info-area {
            margin-bottom: 25px;
        }

        .st-name {
            font-size: 28px;
            font-weight: 800;
            color: #1e293b;
            margin-bottom: 5px;
            line-height: 1.1;
        }

        .st-id {
            font-size: 15px;
            font-weight: 700;
            color: #64748b;
            margin-bottom: 5px;
        }

        .st-faculty {
            font-size: 14px;
            font-weight: 700;
            color: #6366f1;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .qr-wrapper {
            padding: 10px;
            border: 2px dashed #e2e8f0;
            border-radius: 15px;
            display: inline-block;
        }

        .footer-text {
            position: absolute;
            bottom: 15px;
            left: 0;
            width: 50%;
            font-size: 12px;
            color: #94a3b8;
            font-weight: 600;
        }

        /* Print Specifics */
        @media print {
            @page {
                size: A5 landscape;
                margin: 0;
            }
            body { background: white !important; }
            .no-print { display: none !important; }
            .page-container {
                width: 210mm !important;
                height: 148mm !important;
                box-shadow: none !important;
            }
        }

        .btn-print {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #1e293b;
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            font-weight: 700;
            text-decoration: none;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            z-index: 100;
        }
    </style>
</head>
<body>

    <a href="javascript:void(0)" onclick="window.print()" class="btn-print no-print">🖨️ Print Student Card</a>

    <div class="page-container">
        <div class="content-box">
            <div class="photo-frame">
                <?php 
                    $photo = $student['photo_path'];
                    if(!file_exists("../" . $photo) || empty($photo)) {
                        $photo = "assets/images/default_student.png";
                    }
                ?>
                <img src="../<?= $photo ?>?v=<?= time() ?>" alt="">
            </div>

            <div class="info-area">
                <h1 class="st-name"><?= htmlspecialchars($student['full_name']) ?></h1>
                <div class="st-id">ID: <?= htmlspecialchars($student['student_id']) ?></div>
                <div class="st-faculty"><?= htmlspecialchars($student['faculty']) ?></div>
            </div>

            <div class="qr-wrapper">
                <div id="qr-target"></div>
            </div>
        </div>
        
        <!-- Right half is empty as requested -->
    </div>

    <script>
        new QRCode(document.getElementById("qr-target"), {
            text: "<?= $student_id ?>",
            width: 140,
            height: 140,
            colorDark : "#000000",
            colorLight : "#ffffff",
            correctLevel : QRCode.CorrectLevel.H
        });
    </script>
</body>
</html>
